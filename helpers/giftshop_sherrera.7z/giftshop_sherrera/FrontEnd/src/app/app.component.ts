import { Component, NgModule } from '@angular/core';
import {NgbPaginationModule, NgbAlertModule} from '@ng-bootstrap/ng-bootstrap';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { fas, faShoppingCart  } from '@fortawesome/free-solid-svg-icons';
import { FaIconLibrary } from '@fortawesome/angular-fontawesome';
import { far } from '@fortawesome/free-regular-svg-icons';
import { map, Observable } from 'rxjs';
import { CartShop } from './components/cart-shop/cartShopModel';
import { AppService } from './app.component.service';
import { TableArtsModel } from './components/table/tableArtsModel';
import { CartShopComponent } from './components/cart-shop/cart-shop.component';
import { ThisReceiver } from '@angular/compiler';
import { UsersService } from './components/login/users.service';
import { CookieService } from 'ngx-cookie-service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']

})

export class AppComponent {
  faShoppingCart = faShoppingCart;
  countItems:number[];
  artsAddCart:Observable<number[]>;
  itemsCart:TableArtsModel[];
  userLoged:string;

  constructor(private modalService: NgbModal,library: FaIconLibrary, private api:AppService,public userService: UsersService,private cookies: CookieService,public router: Router) {
    library.addIconPacks(fas, far);
    (this.api.getDataObject()).subscribe(
      (data) => {

       this.itemsCart = data;
      },
      (error) => {
        console.log("error");
      }
    ).add(() => {
      //console.log("bien hecho");
    });

    this.artsAddCart = api.getDataObject().pipe(
      map((res) => {
        return res.length;
      })
    );
    this.userLoged = this.userService.getUserLogged();

  }

  public open(modal: any): void {
    const modalRef = this.modalService.open(CartShopComponent,{size: 'lg' });
    modalRef.componentInstance.infoArts = modal;
  }

  logOut(){

     this.cookies.delete("token");
     location.reload();
     this.router.navigateByUrl('/');
  }
}
