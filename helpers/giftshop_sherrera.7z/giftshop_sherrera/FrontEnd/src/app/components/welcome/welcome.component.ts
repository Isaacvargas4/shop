import { Component, OnInit, ViewChild } from '@angular/core';
import { NgbCarousel, NgbSlideEvent } from '@ng-bootstrap/ng-bootstrap';
import { TableService } from '../table/table.component.service';
import { TableArtsModel } from '../table/tableArtsModel';

@Component({
  selector: 'app-welcome',
  templateUrl: './welcome.component.html',
  styleUrls: ['./welcome.component.css']
})
export class WelcomeComponent implements OnInit {

  @ViewChild('carousel', { static: true }) carousel: NgbCarousel;
  tableArts: TableArtsModel[];
  images = [
    {title: 'First Slide', short: 'First Slide Short', src: "https://picsum.photos/id/700/900/500"},
    {title: 'Second Slide', short: 'Second Slide Short', src: "https://picsum.photos/id/1011/900/500"},
    {title: 'Third Slide', short: 'Third Slide Short', src: "https://picsum.photos/id/984/900/500"}
  ];
  constructor(private service: TableService) { }

  ngOnInit(): void {
    this.getArts();
  }

  async getArts() {
    (await this.service.getArts()).subscribe(
      (data) => {
        this.tableArts = data;
      },
      (error) => {
        console.log("error");
      }
    ).add(() => {
    });
  }
}
