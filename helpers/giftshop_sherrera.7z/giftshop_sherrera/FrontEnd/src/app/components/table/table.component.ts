import { Component, OnInit } from '@angular/core';
import { TableModel } from '../table/tableModel';
import { TableService } from '../table/table.component.service';
import { TableArtsModel } from './tableArtsModel';
import { AppService } from 'src/app/app.component.service';
import { Output, EventEmitter } from '@angular/core'
import Swal from 'sweetalert2';
import { UsersService } from '../login/users.service';
import { faCartPlus } from '@fortawesome/free-solid-svg-icons';


@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.css']
})


export class TableComponent implements OnInit {
  tableModelData: TableModel[] = [];
  tableArts: TableArtsModel[];
  tableArts2: TableArtsModel[] = [];
  artsCart: TableArtsModel[] = [];
  pageSize = 8;
  page = 1;
  countItems = 0;
  public model: any;
  faCartPlus = faCartPlus;

  searchText = "";
  @Output() newItemEvent = new EventEmitter<string>();

  constructor(private service: TableService, private parentService: AppService,public userService: UsersService) {

  }

  async ngOnInit() {

    this.getArts();
  }


  async getArts() {
    (await this.service.getArts()).subscribe(
      (data) => {
        this.tableArts = data;
      },
      (error) => {
        console.log("error");
      }
    ).add(() => {
    });
  }

  addToCart(val: any) {
    let userLoged = this.userService.getUserLogged();
    if(userLoged ==''){
      Swal.fire({
        position: 'center',
        icon: 'info',
        title: 'Please login to start adding items to cart',
        showConfirmButton: false,
        timer: 2500
      })
      return
    }


    let valueFind = this.artsCart.find(element => element.id == val.id);
    if (!valueFind) {
      val.quantity = 1;
      this.artsCart.push(val);
      this.parentService.setDataObject(this.artsCart);
      this.newItemEvent.emit(val);
      Swal.fire({
        position: 'center',
        icon: 'success',
        title: 'Your item has been added',
        showConfirmButton: false,
        timer: 1500
      })
    }
  }
  Search() {
    // alert(this.searchText)
    if (this.searchText !== "") {
      let searchValue = this.searchText.toLocaleLowerCase();

      this.tableArts = this.tableArts.filter((contact: any) => {
        return contact.title.toLocaleLowerCase().match(searchValue);
      });
    }
    else {
      this.getArts();
    }
  }
}
