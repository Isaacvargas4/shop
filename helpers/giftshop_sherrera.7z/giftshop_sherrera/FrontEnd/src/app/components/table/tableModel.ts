export interface TableModel {
    id: string;
    name: string;
    status: number;
}
