import { Injectable } from '@angular/core';
import { HttpClient, HttpEvent, HttpHeaders } from '@angular/common/http';
import { TableModel } from '../table/tableModel';
import { Observable, Subject, throwError } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';
import { GenericHttpService2 } from '../general/generic2.http.service';

@Injectable({
  providedIn: 'root'
})
export class TableService extends GenericHttpService2<TableModel> {
  subject: Subject<number> = new Subject();

  constructor( private httpClient: HttpClient) {
    super(httpClient);
  }
  //private readonly apiController: string = 'user';

  async getArts(): Promise<Observable<any>> {
    return this.httpClient.get(` https://fakestoreapi.com/products`);
  }


  setDataObject(obj:any) {
    this.subject.next(obj);
  }

  getDataObject(): Observable<any> {
    return this.subject;
  }
}
