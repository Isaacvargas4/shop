import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { TableArtsModel } from '../table/tableArtsModel';
import { TableModel } from '../table/tableModel';
@Injectable({
  providedIn: 'root'
})

export class CheckOutService {
  subject: Subject<TableArtsModel[]> = new Subject();
  constructor() {

  }
  setDataObject(obj:any) {
    console.log(obj);
    this.subject.next(obj);
  }

  getDataObject(): Observable<any> {
    return this.subject;
  }

  setDataObjectPrint(obj:any) {
    console.log(obj);
    this.subject.next(obj);
  }

  getDataObjectPrint(): Observable<any> {
    return this.subject;
  }
}
