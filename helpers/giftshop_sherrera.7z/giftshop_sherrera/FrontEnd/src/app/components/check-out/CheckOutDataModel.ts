export interface CheckOutData {
  firstName: string;
  lastName: string;
  email: string;
  email2: string;
  address: string;
  address2: string;
  country: string;
  state: string;
  zip: string;
}
