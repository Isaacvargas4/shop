export interface CheckOutPayment {
  typeCard:number;
  nameOnCard:string;
  cardNumber:string;
  expiration:string;
  cvv:number;
}
