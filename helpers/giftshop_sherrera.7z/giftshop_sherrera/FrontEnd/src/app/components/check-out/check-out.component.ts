import { Component, Injectable, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';

import { AppService } from 'src/app/app.component.service';
import { CartShopService } from '../cart-shop/cart-shop.component.service';
import { TableArtsModel } from '../table/tableArtsModel';
import { CheckOutService } from './check-out.component.service';
import { CheckOutData } from './CheckOutDataModel';
import { CheckOutPayment } from './CheckOutPaymentModel';
import { Output, EventEmitter } from '@angular/core';
import { first } from 'rxjs';
import { DatePipe } from '@angular/common';
import Swal from 'sweetalert2';
import { faPrint,faCreditCardAlt } from '@fortawesome/free-solid-svg-icons';


@Injectable({
  providedIn: 'root'
})

@Component({
  selector: 'app-check-out',
  templateUrl: './check-out.component.html',
  styleUrls: ['./check-out.component.css']
})
export class CheckOutComponent implements OnInit {
  arts: Array<TableArtsModel> = [];
  code: number;
  codeText: string;
  total: number;
  UserForm: FormGroup;
  PaymentForm: FormGroup;
  userInfo: CheckOutData;
  userPayment: CheckOutPayment;
  firstNamePrint: string = "";
  lastNamePrint: string = "";
  emailPrint: string = "";
  addressPrint: string = "";
  invoiceNumber: number;
  dateInvoice: Date = new Date();
  pipe = new DatePipe('en-US');
  dateFormat: string | null;
  payments:boolean = false;
  faPrint = faPrint;
  faPayment = faCreditCardAlt;

  @Output() bookTitleCreated = new EventEmitter<{ title: CheckOutData }>();
  bookTitle: string = "";

  constructor(private route: ActivatedRoute, private api: AppService, private data: CartShopService, private formBuilder: FormBuilder, private formBuilderPayment: FormBuilder) {
    this.UserForm = this.formBuilder.group({
      firstName: '',
      lastName: '',
      email: '',
      email2: '',
      address: '',
      address2: '',
      country: '',
      state: '',
      zip: '',
    });
    this.PaymentForm = this.formBuilderPayment.group({
      typeCard: '',
      nameOnCard: '',
      cardNumber: '',
      expiration: '',
      cvv: '',
    });
  }

  ngOnInit(): void {
    this.code = 0;
    this.arts = this.data.retrieveIDs();
    this.calculateTotal();
    this.generateInvoice();
  }

  Check() {
    this.arts = this.data.retrieveIDs();

  }
  calculateTotal() {
    this.verifyCode(this.codeText);
    this.total = this.arts.reduce((accumulator, object) => {
      return accumulator + object.price;
    }, 0);
    this.total = this.total - Number(this.code);
  }

  verifyCode(code: string) {
    if (code == "Sergio") return this.code = 10;

    if (code == "Rosendo") return this.code = 5;

    return this.code = 0;
  }
  CheckInfo() {

    if (this.PaymentForm.value['typeCard'] == '' || this.PaymentForm.value['nameOnCard'] == '' || this.PaymentForm.value['cardNumber'] == '' ||
      this.PaymentForm.value['expiration'] == '' || this.PaymentForm.value['cvv'] == '') {
      Swal.fire(
        'Error',
        'Verify payment data',
        'error'
      )
      return;
    }

    Swal.fire({
      title: 'Do you want to proceed to checkout?',
      showDenyButton: false,
      showCancelButton: true,
      confirmButtonText: 'Yes',
    }).then((result) => {
      /* Read more about isConfirmed, isDenied below */
      if (result.isConfirmed) {
        Swal.fire('Confirm wait a moment...', '', 'success')
        this.payments= true;
      } else if (result.dismiss) {
      }
    })

  }
  Print() {
window.print();

  }
  onAddTitle() {
    this.bookTitleCreated.emit({ title: this.userInfo });
  }
  generateInvoice() {

    return this.invoiceNumber = Math.floor(Math.random() * 10000);
  }
}

