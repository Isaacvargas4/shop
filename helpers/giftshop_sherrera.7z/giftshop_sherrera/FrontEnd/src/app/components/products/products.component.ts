import { Component, IterableDiffers, OnInit } from '@angular/core';
import { AppService } from 'src/app/app.component.service';
import { UsersService } from '../login/users.service';
import { TableService } from '../table/table.component.service';
import { TableArtsModel } from '../table/tableArtsModel';
import { faCartPlus, faTrash, faAdd, faEdit } from '@fortawesome/free-solid-svg-icons';
import { ModalDismissReasons, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import Swal from 'sweetalert2';
import { FormBuilder, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})

export class ProductsComponent implements OnInit {
  faCartPlus = faCartPlus;
  faTrash = faTrash;
  faAdd = faAdd;
  faEdit = faEdit;
  tableArts: TableArtsModel[];
  closeResult = '';
  titleModal: string = "Add Product"
  buttonModdal: string = "Save";
  productForm: FormGroup;
  categorys: string[] = [];
  title: string;
  description: string;
  price: number;
  id: number;
  category: string;
  product: TableArtsModel;

  constructor(private service: TableService, private parentService: AppService, public userService: UsersService, private modalService: NgbModal, private formBuilder: FormBuilder) {

    this.productForm = this.formBuilder.group({
      id: '',
      title: '',
      price: '',
      description: '',
      category: ''
    });
  }

  ngOnInit(): void {
    this.getArts();

  }

  async getArts() {
    (await this.service.getArts()).subscribe(
      (data) => {
        this.tableArts = data;
      },
      (error) => {
        console.log("error");
      }
    ).add(() => {

    });
  }
  open(content: any, item: any, type: number,index:number) {
    this.getUniques();
    if (type == 1) {
      this.titleModal = "Add product";
      this.buttonModdal = "Save";
    }
    if (type == 2) {
      this.product = item;
      this.productForm.patchValue(this.product);
      this.buttonModdal = "Update";
      this.titleModal = "Edit product";
    }
    if (type == 3) {
      this.onDelete(index);
      return;
    }
    this.modalService.open(content, { ariaLabelledBy: 'modal-basic-title' }).result.then(
      (result) => {
        this.saveItem(item, type);
        this.closeResult = `Closed with: ${result}`;
      },
      (reason) => {
        this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
      },
    );
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

  onDelete(id: any) {
    Swal.fire({
      title: 'Are you sure?',
      text: "You won't be able to revert this!",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
      if (result.isConfirmed) {
        this.tableArts.splice(id,1);
        Swal.fire(
          'Deleted!',
          'The product has been deleted.',
          'success'
        )
      }
    })
  }

  saveItem(item: any, type: any) {
    if (type == 1) {
      this.onSave(item);
    }
    if (type == 2) {
      this.onEdit(item);
    }
  }

  onEdit(item: any) {
    this.tableArts[item.id-1].title = this.productForm.value['title'];
    this.tableArts[item.id-1].description = this.productForm.value['description'];
    this.tableArts[item.id-1].price = this.productForm.value['price'];
    this.tableArts[item.id-1].category = this.productForm.value['category'];

    Swal.fire({
      position: 'center',
      icon: 'success',
      title: 'Register updated succesfully',
      showConfirmButton: false,
      timer: 2000
    })

  }
  onSave(item: any) {
    this.productForm.value['id'] = this.tableArts.length + 1;
    this.productForm.value['category'] = 'Custom';
    this.productForm.value['rating']['rate'] = 5;
    this.productForm.value['rating']['count'] = 0;
    this.productForm.value['image'] = 'https://fakestoreapi.com/img/61pHAEJ4NML._AC_UX679_.jpg';
    this.tableArts.push(this.productForm.value);
    Swal.fire({
      position: 'center',
      icon: 'success',
      title: 'Register added succesfully',
      showConfirmButton: false,
      timer: 2000
    })

  }
  getUniques() {
    this.tableArts.forEach(element => {
      if (!this.categorys.includes(element.category))
        this.categorys.push(element.category);
    });
  }
}
