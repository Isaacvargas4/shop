import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { CanActivate } from '@angular/router';
import { UsersService } from '../login/users.service';
import Swal from 'sweetalert2';

@Injectable()
export class CanActivateViaAuthGuard implements CanActivate {

  constructor(private authService: UsersService, private router: Router) { }

  canActivate() {
    let userLoged = this.authService.getUserLogged();
    if (userLoged == "") {
        Swal.fire({
          position: 'center',
          icon: 'info',
          title: 'Please first login ',
          showConfirmButton: false,
          timer: 2500
        })

      this.router.navigate(['/login']);
      return false;
    }

    return true;
  }
  canActivateAdmin() {
    let userLoged = this.authService.getUserLogged();
    if (userLoged != "janet.weaver@reqres.in") {


      this.router.navigate(['/welcome']);
      return false;
    }

    return true;
  }
}
