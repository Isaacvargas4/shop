import { HttpClient, HttpEvent } from '@angular/common/http';

import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class GenericHttpService2<T> {
  constructor(private http: HttpClient) {}

  get apiUrl(): string {
    return "https://localhost:5031";
  }

  get(endpoint: string, options?: any): Observable<HttpEvent<T[]>> {
    return this.http.get<T[]>(`${this.apiUrl}/${endpoint}`, options);
  }

  getSingle(endpoint: string, options?: any): Observable<HttpEvent<T>> {
    return this.http.get<T>(`${this.apiUrl}/${endpoint}`, options);
  }

  post(endpoint: string, data: T, options?: any): Observable<any> {
    return this.http.post<T>(`${this.apiUrl}/${endpoint}`, data, options);
  }

  put(endpoint: string, data: T, options?: any): Observable<any> {
    return this.http.put<T>(`${this.apiUrl}/${endpoint}`, data, options);
  }

  remove(endpoint: string, options?: any): Observable<any> {
    return this.http.delete<any>(`${this.apiUrl}/${endpoint}`, options);
  }
}
