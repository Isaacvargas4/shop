import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UsersService } from '../login/users.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-new-user',
  templateUrl: './new-user.component.html',
  styleUrls: ['./new-user.component.css']
})
export class NewUserComponent implements OnInit {
  email: string;
  password: string;
  confirmPassword: string;
  passwordError: boolean;
  agreeStatements: boolean = false;
  constructor(public userService: UsersService, public router: Router) { }

  ngOnInit(): void {
  }
  register() {
    const user = { email: this.email, password: this.password };
    this.userService.register(user).subscribe(data => {
      this.userService.setToken(data.token);
      this.router.navigateByUrl('/');
    });
  }

  verifyData() {

    if(this.email ==null || this.email==undefined){
      Swal.fire({
        icon: 'error',
        title: 'Verify',
        text: 'Email could not be empty',
      })

      return;
    }
    if(this.password != this.confirmPassword){
      Swal.fire({
        icon: 'error',
        title: 'Verify',
        text: 'Password does not match',
      })

      return;
    }

    if (this.agreeStatements == false) {
      Swal.fire({
        icon: 'info',
        title: 'Agree all the statemets'
      })

      return;
    }
    this.register();
  }

}
