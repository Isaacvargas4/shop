import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CartShopService {

  myIds: Array<any> = [];
  myDataUser: any;
  constructor() {
  }
  saveIds(produIds: any) {
    this.myIds = produIds;
  }
  retrieveIDs() {
    return this.myIds;
  }

  saveIdsPrint(produIds: any) {
    this.myDataUser = produIds;
  }
  retrieveIDsPrints() {
    return this.myDataUser;
  }

}
