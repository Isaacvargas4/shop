import { Component, ElementRef, Input, OnInit, ViewChild } from '@angular/core';
import { Observable } from 'rxjs';
import { TableArtsModel } from '../table/tableArtsModel';
import {NgbActiveModal, NgbModal, NgbModalModule, NgbModalOptions, NgbModalRef} from '@ng-bootstrap/ng-bootstrap'
import { NavigationExtras, Router } from '@angular/router'
import { CheckOutService } from '../check-out/check-out.component.service';
import { CheckOutComponent } from '../check-out/check-out.component';
import { CartShopService } from './cart-shop.component.service';
import { faTimes,faArrowLeft,faArrowRight } from '@fortawesome/free-solid-svg-icons';
@Component({
  selector: 'app-cart-shop',
  templateUrl: './cart-shop.component.html',
  styleUrls: ['./cart-shop.component.css']
})
export class CartShopComponent implements OnInit {
  @Input() infoArts: TableArtsModel[]; // decorate the property with @Input()
  total: number;
  message:string;
  @ViewChild('myModal', { static: false }) myModal:NgbModalRef;
  faTimes = faTimes;
  faArrowLeft = faArrowLeft;
  faArrowRight = faArrowRight;
  totalItems:number = 0;
  quantity:number = 2;
  inforartsOriginal:any;

  constructor(public activeModal: NgbActiveModal, private _router:Router,private serviceCheckout:CheckOutService, private service:CartShopService) { }

  ngOnInit(): void {
    console.log(this.infoArts)
    if (this.infoArts != undefined) {
      this.inforartsOriginal = this.infoArts;
      this.totalItems = this.infoArts.length;
      this.calculateTotal();
    }
    //this.service.currentMessage.subscribe(message => this.message = message)
  }

  calculateTotal() {
    this.total = this.infoArts.reduce((accumulator, object) => {
      console.log(object.price,"..",object.quantity)
      return accumulator + object.price * object.quantity;
    }, 0);
  }

  closeCustom(){
    this.activeModal.close();
    if(this.infoArts == undefined) return;
    this._router.navigate(["checkout"]);
    this.service.saveIds(this.infoArts)
  }

  calculateNewTotal(id:any){
  //this.infoArts[id].quantity = this.quantity
  this.calculateTotal();
  }
}
