export interface CartShop {
  countArts:number;
}
