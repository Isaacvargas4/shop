import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UsersService } from './users.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  email: string;
  password: string;
 userLoged:string;
  constructor(public userService: UsersService,public router: Router) { }

  ngOnInit(): void {
    this.userLoged = this.userService.getUserLogged();

    if(this.userLoged !=''){
      this.router.navigateByUrl('/welcome');
    }


  }
  login() {
    const user = { email: this.email, password: this.password };
    this.userService.login(user).subscribe(
      data => {
        this.userService.setToken(data.token);
        location.reload();

      },
      error => {
        Swal.fire({
          icon: 'error',
          title: 'Verify',
          text: 'User o email doesnt exist',
        })

      });
  }

  verifyData() {

    if(this.email ==null || this.email==undefined){
      Swal.fire({
        icon: 'error',
        title: 'Verify',
        text: 'Email could not be empty',
      })

      return;
    }
    if(this.password  ==null || this.email==undefined){
      Swal.fire({
        icon: 'error',
        title: 'Verify',
        text: 'Password could not be empty',
      })

      return;
    }


    this.login();
  }
}
