import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CheckOutComponent } from './components/check-out/check-out.component';
import { CanActivateViaAuthGuard } from './components/general/CanActivateViaAuthGuard';
import { LoginComponent } from './components/login/login.component';
import { NewUserComponent } from './components/new-user/new-user.component';
import { ProductsComponent } from './components/products/products.component';
import { TableComponent } from './components/table/table.component';
import { WelcomeComponent } from './components/welcome/welcome.component';

@NgModule({
  imports: [
    RouterModule.forRoot([
    { path:  'tabledata',  component:  TableComponent,canActivate: [CanActivateViaAuthGuard]  } ,
    { path:  'welcome',  component:  WelcomeComponent },
    { path:  'register',  component:  NewUserComponent },
    { path:  'checkout',  component:  CheckOutComponent, canActivate: [CanActivateViaAuthGuard]},
    { path:  'products',  component:  ProductsComponent, canActivate: [CanActivateViaAuthGuard] },
    { path:  'login',  component:  LoginComponent},
    { path:  '',  component:  WelcomeComponent},

  ])
],
  exports: [RouterModule]

})

export class AppRoutingModule { }

