import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {RouterModule} from '@angular/router'
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { TableComponent } from './components/table/table.component';
import { HttpClientModule } from '@angular/common/http';
import * as $ from 'jquery';
import { NewUserComponent } from './components/new-user/new-user.component';
import { FontAwesomeModule, FaIconLibrary } from '@fortawesome/angular-fontawesome';
import { CartShopComponent } from './components/cart-shop/cart-shop.component';
import { CheckOutComponent } from './components/check-out/check-out.component';
import { SweetAlert2Module } from '@sweetalert2/ngx-sweetalert2';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxMaskModule, IConfig } from 'ngx-mask';
import { WelcomeComponent } from './components/welcome/welcome.component';
import { LoginComponent } from './components/login/login.component';
import { CanActivateViaAuthGuard} from '../app/components/general/CanActivateViaAuthGuard';
import { ProductsComponent } from './components/products/products.component';


@NgModule({
  declarations: [
    AppComponent,
    TableComponent,
    NewUserComponent,
    CartShopComponent,
    CheckOutComponent,
    WelcomeComponent,
    LoginComponent,
    ProductsComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgbModule,
    HttpClientModule,
    FontAwesomeModule,
    RouterModule.forRoot([]),
    SweetAlert2Module.forRoot(),
    FormsModule,
    ReactiveFormsModule,
    NgxMaskModule.forRoot(),
  ],
  providers: [ CanActivateViaAuthGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
