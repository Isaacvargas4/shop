import { Injectable } from '@angular/core';
import { HttpClient, HttpEvent, HttpHeaders } from '@angular/common/http';
import { Observable, Subject, throwError } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';
import { TableArtsModel } from './components/table/tableArtsModel';


@Injectable({
  providedIn: 'root'
})
export class AppService {
  subject: Subject<TableArtsModel[]> = new Subject();
  subjectArts: Subject<number> = new Subject();
  constructor( private httpClient: HttpClient) {

  }
  setDataObject(obj:any) {
    this.subject.next(obj);
  }

  getDataObject(): Observable<any> {
    return this.subject;
  }

}
