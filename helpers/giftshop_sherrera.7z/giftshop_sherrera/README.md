Login: 
User: janet.weaver@reqres.in
Password: Any --> i've doesnt matter

To register user the same user login.